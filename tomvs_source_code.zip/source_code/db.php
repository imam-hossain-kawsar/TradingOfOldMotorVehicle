<?php

$username = 'root';
$password = '';
$connection = new PDO( 'mysql:host=localhost;dbname=tomvs', $username, $password );

?>