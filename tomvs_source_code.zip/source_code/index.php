<?php
	session_start();
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Make your dream true">
        <meta name="keywords" content="">

        <link rel="shortcut icon" type="image/ico" href="icon5.png"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="media.css">
        <link rel="stylesheet" href="animate.css">
        <link rel="stylesheet" href="global.css">
        <link rel="stylesheet" href="home.css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800" rel="stylesheet">
        <title> Home</title>
        <link rel="stylesheet" href="about.css">
		<script type="text/javascript" src="wow.min.js"></script>
		<script type="text/javascript">
			new WOW().init();
			smoothScroll.init();
		</script>
		<style>
			.story .my-story{
				background-color:white;
			}
			.story .my-story:hover{
				background:rgba(65, 133, 251, 0.39);
				transition:0.5s;
			}
			.action a:hover{
				background:rgba(65, 133, 251, 0.39);
			}
		</style>

        
    </head>
    <body style="background-color:white;">
        <nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#294160;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">
                        <img src="icon5.png" alt="" style="width: 70px;position: relative;top: -25px;float: left;" />
                        <h1 style="font-size: 30px;float: left;margin-top: 0px;margin-left: 5px;font-weight: bold;  color:white;">TOMVS</h1>
                    </a>
                </div>
                
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					
                    <ul class="nav navbar-nav navbar-right">
					
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="text-shadow:0 0 8px #fd0202; color:white;">
                                <i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                                <i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                                <i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="sessionCheck.php"><i class="fa fa-caret-square-o-down" aria-hidden="true"></i> ADMIN PANEL</a></li>
                                
    
                            </ul>
                        </li>
						
                    </ul>
                </div>
            </div>
        </nav>

<br><br><br><br>
<br><br><br><br>
<br><br><br><br>
<br>

	<div  style="margin-top:-80px;background-color:white; height:300px;">
		<div class="site-aim" style="padding-left:150px;padding-top:70px;margin:auto;">
			<h1 style="color:#294160;font-face:BringHeart-regular " class="wow fadeInUp" >Let's make your dream true !</h1>
			<p style="align:center;" class="wow fadeInLeft" >Start your journey with us & achieve your goal.</p>	
		</div>
	</div>

<br>
<br>
<br>
<br><br><br>


<div class="action" style="background-color: white;">
    
    <a href="viewindex.php"  >View</a>
    
</div>

<br><br><br><br>
<div class="container story">
    <h1 style=" color:#294160;" >Our Stories & Team</h1>
    
    <div class="col-md-4">
        <div class="my-story" >
            <img src="kawsar_edited_another.jpg" alt=""/>

            <h4>Imam Hossain Kawsar</h4>
            <i class="fa fa-location-arrow" aria-hidden="true"></i> Dhaka - Bangladesh
            <p>Software Engineer, IIT, University of Dhaka </p>
        </div>

    </div>

	
	 <div class="col-md-4">
        <div class="my-story" >
            <img src="nadiamam2.jpg" alt=""/>

            <h4>Nadia Nahar</h4>
            <i class="fa fa-location-arrow" aria-hidden="true"></i> Dhaka - Bangladesh
            <p>Lecturer, IIT, University of Dhaka </p>
        </div>

    </div>

    <div class="col-md-4">
        <div class="my-story" >
            <img src="ibrahim.jpg" alt=""/>

            <h4>Ibrahim Khalil</h4>
            <i class="fa fa-location-arrow" aria-hidden="true"></i> Dhaka - Bangladesh
            <p>Software Engineer, IIT, University of Dhaka</p>
        </div>

    </div>
	
	
    
</div>

<br>







<div class="modal fade" id="sign-up-newlater" style="margin-top: 200px;">
    <div class="modal-dialog sign-up-newlater">

        <div>
            <!--newsletter form-->
            <div class="row">
                <a href="" class="close_it-model" data-dismiss="modal" aria-hidden="true"><i class="fa fa-close"></i></a>
                <h3 style="margin-top: 0;">GET NOTIFIED OF NEW CAR</h3>

                <p id="newlreponce" style="color: red;font-family: sans-serif;"></p>
                <input type="email" class="form-control col-sm-8" placeholder="Enter your email here" id="news-later-email" name="news-later-email">
                <input type="submit" class="btn" value="subscribe" id="btn-newlatter">
                <p>YOUR EMAIL ADDRESS WILL NEVER BE SHARED</p>
            </div>
            <div class="clearfix"></div>



        </div>
    </div>
</div>



            <script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.20.4/TweenMax.min.js"></script>
			<script src="animate-scroll.js"></script>
			<script type="text/javascript">
				$(document).animateScroll();
			</script>
			
    </body>
</html>
