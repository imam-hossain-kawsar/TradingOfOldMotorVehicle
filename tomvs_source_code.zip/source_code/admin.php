<?php
	session_start();
	
	$j = $_SESSION['i'];
	if($j==1 and $_SESSION['email']=="tomvsbsse8@gmail.com"){
		$status = 'true';
		
	}
	else{
		header("location:common_message.php");
	}

?>



<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Make your dream true">
        <meta name="keywords" content="">
        <link rel="shortcut icon" type="image/ico" href="icon5.png"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="media.css">
        <link rel="stylesheet" href="animate.css">
        <link rel="stylesheet" href="global.css">
        <link rel="stylesheet" href="home.css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800" rel="stylesheet">
        <title> Admin</title>
		<script type="text/javascript" src="wow.min.js"></script>
		<script type="text/javascript">
			new WOW().init();
			smoothScroll.init();
		</script>
        <link rel="stylesheet" href="about.css">
       <!-- <script src="security.js"></script>-->
        <?php include 'css/css.html'; ?>
        
        

    </head>
    <body style="background-color:white;">
		<div class="experiment" style="background-color:white; height:10px;">
			

		</div>
        <nav class="navbar navbar-inverse" style="background-color:#294160; color:white;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">
                        <img src="icon5.png" alt="" style="width: 70px;position: relative;top: -25px;float: left;" />
                        <h1 style="font-size: 30px;float: left;margin-top: 0px;margin-left: 5px;font-weight: bold;">TOMVS</h1>
                    </a>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                       
						 <li><a href="carindex.php" style=" border-left: none; color:white;">CAR</a></li>
						<li><a href="bikeindex.php" style=" color:white;">BIKE</a></li>
						<li><a href="equipmentindex.php" style=" color:white;">EQUIPMENT</a></li>
						<li><a href="transactionindex.php" style=" color:white;">TRANSACTION</a></li>
						<li><a href="customerlistindex.php" style=" color:white;">CUSTOMERLIST</a></li>
						<li><a href="advertisementlist.php" style=" color:white;">ADVERTISEMENT</a></li>
						
						<?php
							if(isset($_SESSION['first_name'])){
								$first_name = $_SESSION['first_name'];
								$welcome = '<font style="color:white;font-size:20px;"> welcome</font>';
								echo $welcome.",".$first_name;
								$logout = '
									<li><a href="logout.php"><i  style="color:red;font-size:20px; ">logout</i></a></li>
								';
								echo $logout;
							}
							
						?>
                    </ul>
                </div>
            </div>
        </nav>

<br><br>

 <div style="background-color:white; height:400px;position:sticky;">
		<div class="site-aim" style="padding-left:100px;padding-top:70px;margin:auto;">
            <h1 style=" color:#294160;font-face:BringHeart-regular " class="wow fadeInUp">Make your customer happy !</h1>
            <p style="color:black; font-face:BringHeart-regular " class="wow fadeInLeft">Thanks for being with us.</p>
        </div>
	  
</div>
	  

<br><br><br><br><br><br>
 <div style="background-color:#0a0c12; height:400px;">
  <br>
  <h4 style="text-align:center;color:white;">Contact us</h4>

	<div class="row">
	  <div class="column" style="padding-left:210px;color:white;width:33%;float:left;">
	  <br>
		<p>Imam Hossain Kawsar<br>Institute of Information Technology<br>University of Dhaka<br>mobile:01521-435856<br>email:bsse0816@iit.du.ac.bd<br></p>

	  </div>
	  <div class="column" style="padding-left:170px;color:white;width:33%;float:left;">
		<br>
		<p>Ibrahim Khalil<br>Institute of Information Technology<br>University of Dhaka<br>mobile:<br>email:bsse0804@iit.du.ac.bd<br></p>
	  </div>
	   <div class="column" style="padding-left:80px;color:white;width:33%;float:left;">
		<br>
		<p>Nadia Nahar<br>Lecturer<br>Institute of Information Technology<br>University of Dhaka<br></p>

	  </div>
</div>

  <br><br><br><br><br><br><br>
  
	<p style="color:white;text-align:center;vertical-align:middle;" >All rights reserved </p>
  
  </div>









             
            <script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <script src="media.js"></script>
            <script src="jquery_cookie.js"></script>
            <script src="home.js"></script>
    </body>
</html>
