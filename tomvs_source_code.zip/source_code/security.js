
	var password;
	var correctpassword = "test";
	password = prompt('please, enter in the password to view this page:');
	if(password == correctpassword){
		alert('password is correct. Click ok to enter.');
	}
	else{
		window.location = "http://localhost/test/index.php";
	}
