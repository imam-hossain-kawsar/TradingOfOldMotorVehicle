<?php

$db = mysqli_connect("localhost", "root", "", "tomvs");

if($db === false){

    die("ERROR: Could not connect. " . mysqli_connect_error());

}

$_SESSION['email'] = $_POST['email'];
$_SESSION['first_name'] = $_POST['firstname'];
$_SESSION['last_name'] = $_POST['lastname'];



$first_name = mysqli_real_escape_string($db, $_REQUEST['firstname']);
$last_name = mysqli_real_escape_string($db, $_REQUEST['lastname']);
$user_name = mysqli_real_escape_string($db, $_REQUEST['username']);
$email = mysqli_real_escape_string($db, $_REQUEST['email']);
$address = mysqli_real_escape_string($db,$_REQUEST['address']);
$mobile = mysqli_real_escape_string($db,$_REQUEST['mobile']);
$password = mysqli_real_escape_string($db, $_REQUEST['password']);
//$password = md5($password);
$hash = (md5(rand(0,1000)));
// Escape user inputs for security



// attempt insert query execution

$sql1 = "SELECT * FROM users WHERE email='$email'";
$result = mysqli_query($db, $sql1);

if (( $result->num_rows) > 0 ) {
    
    
   header("location: email_status.php");
    
    
}
else{
    $sql = "INSERT INTO users (first_name, last_name, user_name,email,address,mobile,password,hash) VALUES ('$first_name', '$last_name','$user_name' ,'$email', '$address', '$mobile', '$password', '$hash')";

    if(mysqli_query($db, $sql)){
        //echo "Account is created. You can log in now!";
       

        // Send registration confirmation link (verify.php)
        $to      = $email;
        $subject = 'Account confirmation ( tomvs.com )';
        $message_body = '
        Hello '.$first_name.',

        Thank you for signing up in TOMVS(Trading of Old Motor Vehicles!),
        Your email: '.$email.',
        Your password: '.$password.'';

       
        mail( $to, $subject, $message_body );

       header("location: auth_message.php"); 
    
    } else{
    
        echo "ERROR: Could not able to execute $sql. " . mysqli_error($db);
    
    }
    


}

 

// close connection

mysqli_close($db);

?>

