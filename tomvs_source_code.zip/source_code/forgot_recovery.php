<?php
    $db = mysqli_connect("localhost", "root", "", "tomvs");
    if($db === false){
    
        die("ERROR: Could not connect. " . mysqli_connect_error());
    
    }
    $email = mysqli_real_escape_string($db, $_REQUEST['email']);
    $query = "SELECT * FROM users WHERE email='$email'";
    $results = mysqli_query($db, $query);
    if ( ($results->num_rows) == 0 ){ 
       
        header("location: common_error.php");
          
    }
    elseif(($results->num_rows) == 1){
       // echo "<script>alert("password is sent to your email."); </script>";
        $query1 = "SELECT password FROM users WHERE email='$email'";
        $results1 = mysqli_query($db, $query1);
        $row = $results1->fetch_assoc();
       // echo $results1;
        $to = $email;
        $subject = "Recover password";
        $msg = 'Your password: '.$row["password"].'';
        mail($to,$subject,$msg);
        header("location: login.php");
    }

?>