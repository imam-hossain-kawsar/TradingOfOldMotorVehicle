<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Make your dream true">
        <meta name="keywords" content="">
        <link rel="shortcut icon" type="image/ico" href="icon5.png"/>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="media.css">
        <link rel="stylesheet" href="animate.css">
        <link rel="stylesheet" href="global.css">
        <link rel="stylesheet" href="home.css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800" rel="stylesheet">

	</head>
<body style="background-color:white;">
        <nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#294160;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">
                        <img src="icon5.png" alt="" style="width: 70px;position: relative;top: -25px;float: left;" />
                        <h1 style="font-size: 30px;float: left;margin-top: 0px;margin-left: 5px;font-weight: bold;  color:white;">TOMVS</h1>
                    </a>
                </div>
                
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					
                    <ul class="nav navbar-nav navbar-right">
						
                    </ul>
                </div>
            </div>
        </nav>
		<br><br><br><br><br>

		<?php
	session_start();
	$host = "localhost";
    $user = "root";
    $password = "";
    $database_name = "tomvs";
    $pdo = new PDO("mysql:host=$host;dbname=$database_name", $user, $password, array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ));
	$search=$_POST['search'];
	if($search == null or $search == ""){
		echo "<h1 style=\"margin-left:550px; color:red;\">Enter Brand Name ...</h1><br/>";
		echo "<img src=\"sorry.jpg\" width=\"500px\" height=\"430px\" align=\"center\" style=\"margin-left:400px;\">";
	}
	else{
		
		
	$query = $pdo->prepare("select * from cars where brand_name LIKE '%$search%' OR model_name LIKE '%$search%'");
	$query->bindValue(1, "%$search%", PDO::PARAM_STR);
	$query->execute();
	
	
	
	if (!$query->rowCount() == 0) {
		 		echo "<h1 style=\"margin-left:550px; color:#294160;\">Search found &nbsp;<img src=\"happy.png\" width=\"30px\" height=\"30px\"></h1><br/><br/>";
				echo "<table style=\"font-family:arial;margin:auto;font-size:30px;border-color:color:white;\">";	
                echo "<tr><td style=\"border-style:solid;border-width:1px;border-color:white;color:white;background:#294160;width:200px;\">Brand_name</td><td style=\"border-style:solid;color:white;border-width:1px;border-color:#294160;background:#294160;\">model_name</td><td style=\"color:white;border-style:solid;border-width:1px;border-color:#294160;background:#294160;\">Price</td></tr>";				
            while ($results = $query->fetch()) {
				echo "<tr><td style=\"border-style:solid;border-width:1px;border-color:#294160;width:200px;\">";			
                echo $results['brand_name'];
				echo "</td><td style=\"border-style:solid;border-width:1px;border-color:#294160;width:200px;\">";
                echo $results['model_name'];
				echo "</td><td style=\"border-style:solid;border-width:1px;border-color:#294160;width:200px;\">";
                echo "$".$results['price'];
				echo "</td></tr>";				
            }
				echo "</table>";		
        } else {
            echo "<h1 style=\"margin-left:550px; color:red;\">Nothing found !!</h1><br/>";
			echo "<img src=\"sorry.jpg\" width=\"500px\" height=\"430px\" align=\"center\" style=\"margin-left:400px;\">";
        }

	}
	
?>





</body>

</html>





