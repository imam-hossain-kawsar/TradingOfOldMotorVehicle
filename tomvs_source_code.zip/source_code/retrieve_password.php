<?php
    
    $db = mysqli_connect("localhost", "root", "", "tomvs");

    if($db === false){
    
        die("ERROR: Could not connect. " . mysqli_connect_error());
    
    }
    else{
        $newpassword = mysqli_real_escape_string($db, $_REQUEST['new_password']);
        $confirmpassword = mysqli_real_escape_string($db, $_REQUEST['confirm_password']);
        if($newpassword == $confirmpassword){
            $sql = "UPDATE users SET password='$newpassword' WHERE email='$email'";
            if(mysqli_query($db, $sql)){
                echo "password updated";
            }
            else{
                echo "does not work!!!";
            }
        }
        else{
            echo "New password and Confirm password does not match";
        }

    }

?>