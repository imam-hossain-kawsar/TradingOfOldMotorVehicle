<?php
	
	session_start();
	
	if((isset($_SESSION['first_name'])) and ($_SESSION['email']!="tomvsbsse8@gmail.com" )){
		header("location: sellform.php");
	}
	elseif((isset($_SESSION['first_name'])) and ($_SESSION['email']=="tomvsbsse8@gmail.com" )){
		header("location: common_message.php");
	}
	else{
		header("location: common_message.php");
	}
	

?>


