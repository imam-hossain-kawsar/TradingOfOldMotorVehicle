<?php
                 // session_start();
                $db = mysqli_connect("localhost", "root", "", "tomvs");

                if($db === false){

                    die("ERROR: Could not connect. " . mysqli_connect_error());

                }
				

            // $_SESSION['email'] = $_REQUEST['email'];
                //$_SESSION['customer_name'] = $_REQUEST['customername'];
                

                // Escape all $_POST variables to protect against SQL injections
				
				
                if(isset($_REQUEST['customername'])){
                    $customer_name = mysqli_real_escape_string($db, $_REQUEST['customername']);

                }
                if(isset($_REQUEST['email'])){
                    $email = mysqli_real_escape_string($db, $_REQUEST['email']);

                }
                if(isset($_REQUEST['address'])){
                    $address = mysqli_real_escape_string($db,$_REQUEST['address']);

                }
                if(isset($_REQUEST['mobile'])){
                    $mobile = mysqli_real_escape_string($db,$_REQUEST['mobile']);

                }
                if(isset($_REQUEST['brand'])){
                    $brand = mysqli_real_escape_string($db,$_REQUEST['brand']);

                }
                if(isset($_REQUEST['model'])){
                    $model=mysqli_real_escape_string($db,$_REQUEST['model']);

                }
                if(isset($_REQUEST['price'])){
                    $price=mysqli_real_escape_string($db,$_REQUEST['price']);

                }
                if(isset($_REQUEST['color'])){
                    $color=mysqli_real_escape_string($db,$_REQUEST['color']);

                }

                if(isset($_REQUEST['producttype'])){
                    $producttype = mysqli_real_escape_string($db,$_REQUEST['producttype']);

                }

                $date = date('Y-m-d H:i:s');
                $orderid = "porder" .rand(1,10000);


                    
                // Check if user with that email already exists
                //$sql1 = "SELECT * FROM users WHERE email='$email'";
                //$result = mysqli_query($db, $sql1);

                // We know user email exists if the rows returned are more than 0
                //if ( $result->num_rows > 0 ) {
                    
                //    $_SESSION['message'] = 'User with this email already exists!';
                //    header("location: error_final.php");
                    
                //}
                //else { // Email doesn't already exist in a database, proceed...

                    // active is 0 by DEFAULT (no need to include it here)
                    if($producttype == 'car'){
                        $sql = "INSERT INTO carpreorder (Orderid, customer_name, email,address,mobile,brand,model,price,color,date,time)
                        VALUES ('$orderid', '$customer_name','$email', '$address', '$mobile', '$brand','$model','$price','$color',NOW(),now())";
                        mysqli_query($db, $sql);
                        $to      = $email;
                        $subject = 'Order Confirmation ( tomvs.com )';
                        $message_body = '
                            Mr/Ms,
                            '.$customer_name.',

                            Thank you for ordering a product!,
                            Your product feature is:,
                            OrderId = '.$orderid.'
                            brand = '.$brand.'
                            model='.$model.'
                            price='.$price.'
                            color='.$color.'
                            You will be notified as soon as ordered product is available!!!';

                            

                            mail( $to, $subject, $message_body );
							header('location:pre_order_success.php');

                
                    }
                    else{
                        $sql = "INSERT INTO bikePreOrder (Orderid, customer_name, email,address,mobile,brand,model,price,color,date,time)
                        VALUES ('$orderid', '$customer_name','$email', '$address', '$mobile', '$brand','$model','$price','$color',now(),now())";
                    
                        mysqli_query($db, $sql);
                        $to      = $email;
                        $subject = 'Order Confirmation ( tomvs.com )';
                        $message_body = '
                            Mr/Ms,
                            '.$customer_name.',

                        Thank you for ordering a product!,
                        Your product feature is:,
                        OrderId = '.$orderid.'
                        brand = '.$brand.'
                        model='.$model.'
                        price='.$price.'
                        color='.$color.'
                        You will be notified as soon as ordered product is available!!!';

                        

                        mail( $to, $subject, $message_body );
                }
                    
                    // Add user to the database
                    /*if ( mysqli_query($db, $sql)){

                        $_SESSION['active'] = 0; //0 until user activates their account with verify.php
                        $_SESSION['logged_in'] = true; // So we know the user has logged in
                        $_SESSION['message'] =
                                
                                "Confirmation link has been sent to $email, please verify
                                your account by clicking on the link in the message!";

                        // Send registration confirmation link (verify.php)
                        $to      = $email;
                        $subject = 'Account Verification ( tomvs.com )';
                        $message_body = '
                        Hello '.$first_name.',

                        Thank you for signing up!

                        Please click this link to activate your account:

                        http://localhost/test/verify_final.php?email='.$email.'&hash='.$hash;  

                        mail( $to, $subject, $message_body );

                        header("location: profile_final.php"); 

                    //}

                    //else {
                    //    $_SESSION['message'] = 'Registration failed!';
                    //    header("location: error_final.php");
                    //}

                //}*/
            ?>