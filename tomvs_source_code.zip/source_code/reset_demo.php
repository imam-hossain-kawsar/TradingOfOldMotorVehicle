<?php
/* Password reset process, updates database with new user password */
session_start();

$db = mysqli_connect("localhost", "root", "", "tomvs");

if($db === false){

    die("ERROR: Could not connect. " . mysqli_connect_error());

}


// Make sure the form is being submitted with method="post"

    // Make sure the two passwords match
    if ( $_REQUEST['newpassword'] == $_REQUEST['confirmpassword'] ) { 

        $new_password = password_hash($_REQUEST['newpassword'], PASSWORD_BCRYPT);
        
        // We get $_POST['email'] and $_POST['hash'] from the hidden input field of reset.php form
        $email = mysqli_real_escape_string($db,$_REQUEST['email']);
        $hash = mysqli_real_escape_string($db,$_REQUEST['hash']);
        
        $sql = "UPDATE users SET password='$new_password', hash='$hash' WHERE email='$email'";

        if ( mysqli_query($db, $sql) ) {

        $_SESSION['message'] = "Your password has been reset successfully!";
        header("location: success.php");    

        }

    }
    else {
        $_SESSION['message'] = "Two passwords you entered don't match, try again!";
        header("location: error_final.php");    
    }


?>