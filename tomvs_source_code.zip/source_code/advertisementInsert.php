<?php
session_start();
include('db.php');
include('advertisementFuction.php');
if(isset($_POST["operation"]))
{
 if($_POST["operation"] == "submitToShopOwner")
 {
	 date_default_timezone_set("Asia/Dhaka");
	 $date = date("d/m/y h:i:sa");
	 $time = date("h:i:sa");
	
	$product_id = 'adv-'.rand(1,100000);
	$image = '';
	$name = $_SESSION['first_name'];
	$email = $_SESSION['email'];
	$mobile = $_SESSION['mobile'];
  if($_FILES["car_image"]["name"] != '')
  {
   $image = upload_image();
  }
  $statement = $connection->prepare("
   INSERT INTO advertisementproduct (advertisement_id, product_type,brand_name, model_name,original_buying_year,fuel,capacity,price,price_condition,color,image,time,customer_name, mobile) 
   VALUES (:product_id,:product_type,:brand_name,:model_name,:oby,:fuel,:capacity,:price,:price_condition,:color, :image,:time, :customer_name, :mobile)
  ");
  $result = $statement->execute(
   array(
    ':product_id' => $product_id,
	':product_type' => $_POST["product_type"],
    ':brand_name' => $_POST["brand_name"],
    ':model_name' => $_POST["model_name"],
    ':oby' => $_POST["oby"],
    ':fuel' => $_POST["fuel"],
    ':capacity' => $_POST["capacity"],
    ':price_condition' => $_POST["price_condition"],
    ':color' => $_POST["color"],
    ':price' => $_POST["price"],
	':time' => $date,
    ':image'  => $image,
	':customer_name' => $name,
	':mobile' => $mobile
   )
  );
  if(!empty($result))
  {
   echo 'thanks! Your sell form succesfully submitted to shop owner';
  }
  else{
	  echo 'wrong!!!!';
  }
 }
}
?>
   