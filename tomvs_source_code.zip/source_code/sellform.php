<?php
	session_start();
	
	$j = $_SESSION['i'];
	if($j==1 and $_SESSION['email']!="tomvsbsse8@gmail.com"){
		$status = 'true';
		
	}
	else{
		include('sellformsession.php');
	}

?>


<html>
 <head>
  <title>SELLFORM</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>  
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link rel="shortcut icon" type="image/ico" href="icon5.png"/>       
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="global.css">

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800" rel="stylesheet">
  <link href="about.css" rel="stylesheet" type="text/css"/>
        
  <style>
    label{
        color: white;
    }
  </style>


 </head>
 <body style="background-color: rgba(27, 97, 255, 0.12);">
 <nav class="navbar navbar-inverse" style="background-color:#294160; color:white;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="viewindex.php">
                        <img src="icon5.png" alt="" style="width: 70px;position: relative;top: -25px;float: left;" />
                        <h1 style="font-size: 30px;float: left;margin-top: 0px;margin-left: 5px;font-weight: bold;">TOMVS</h1>
                    </a>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    
                </div>
            </div>
        </nav>





  <div class="container box">
   
   <br />
   <div class="table-responsive">
   	<h1 align="center" style="color:#294160;">Sell Your Old vehicles !!</h1>

    <br />
    <div align="center">
     <button type="button" id="add_button" data-toggle="modal" data-target="#carModal" class="btn btn-info btn-lg">Click here to sell your Vehicles</button>
    </div>
    <br /><br />
   </div>
  </div>
  

<div id="carModal" class="modal fade">
 <div class="modal-dialog">
  <form method="post" id="car_form" enctype="multipart/form-data">
   <div class="modal-content">
    <div class="modal-header">
     <button type="button" class="close" data-dismiss="modal">&times;</button>
     <h4 class="modal-title">Sell vehicle form</h4>
    </div>
    <div class="modal-body">
	 <label style="color:black;">Enter Product type:&nbsp;</label>
	 <input type="radio" name="product_type" value="car" class="product_type" >&nbsp;car
	 <input type="radio" name="product_type" value="bike" class="product_type" >&nbsp;bike
	<br/>
	
     <label style="color:black;">Enter Brand Name</label>
     <input type="text" name="brand_name" id="brand_name" class="form-control"/>
     <br />
     <label style="color:black;">Enter Model Name</label>
     <input type="text" name="model_name" id="model_name" class="form-control" />
     <br />

     <label style="color:black;">Enter Original Buying Year </label>
     <input type="date" name="oby" id="oby" class="form-control" />
     <br />

     <label style="color:black;">Enter Type of Fuel(CNG,OCTEL,DIESEL etc.)</label>
     <input type="text" name="fuel" id="fuel" class="form-control" />
     <br />

     <label style="color:black;">Enter Engine capacity</label>
     <input type="number" name="capacity" id="capacity" class="form-control" />
     <br />     

     <label style="color:black;">Enter price condition(negotiable/fixed)</label>
     <input type="text" name="price_condition" id="price_condition" class="form-control" />
     <br /> 

     <label style="color:black;">Enter Color of The Car</label>
     <input type="text" name="color" id="color" class="form-control" />
     <br /> 

     <label style="color:black;">Enter Your Demand Price</label>
     <input type="number" name="price" id="price" class="form-control" />
     <br />
     <label style="color:black;">Select vehicle Image</label>
     <input type="file" name="car_image" id="car_image" />
     <span id="car_uploaded_image"></span>
    </div>
    <div class="modal-footer">
     <input type="hidden" name="car_id" id="car_id" />
     <input type="hidden" name="operation" id="operation" />
     <input type="submit" name="action" id="action" class="btn btn-success" value="submitToShopOwner" />
     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
   </div>
  </form>
 </div>
</div>





<script type="text/javascript" language="javascript" >
$(document).ready(function(){
 $('#add_button').click(function(){
  $('#car_form')[0].reset();
  $('.modal-title').text("Sell vehicle form");
  $('#action').val("submitToShopOwner");
  $('#operation').val("submitToShopOwner");
  $('#car_uploaded_image').html('');
 });
 
 

 $(document).on('submit', '#car_form', function(event){
  event.preventDefault();
  var product_type = $('.product_type').val();
  var brandName = $('#brand_name').val();
  var model_name = $('#model_name').val();
  var oby = $('#oby').val();
  var fuel = $('#fuel').val();
  var capacity = $('#capacity').val();
  var price_condition = $('#price_condition').val();
  var color = $('#color').val();
  var price = $('#price').val();
  var extension = $('#car_image').val().split('.').pop().toLowerCase();
  if(extension != '')
  {
   if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)
   {
    alert("Invalid Image File");
    $('#car_image').val('');
    return false;
   }
    var experiment_image=$('#car_image').val();
  } 
  if(brandName != '' && price != '' && model_name !='' && oby != ''  && price_condition!='' && product_type !='' && experiment_image !='')
  {
   $.ajax({
    url:"advertisementInsert.php",
    method:'POST',
    data:new FormData(this),
    contentType:false,
    processData:false,
    success:function(data)
    {
     alert(data);
     $('#car_form')[0].reset();
     $('#carModal').modal('hide');
    }
   });
  }
  else
  {
   alert("All Fields are Required");
  }
 });
 
 
});
</script>

</body>
</html>




   
    