<?php

include('db.php');
include("transactionfunction.php");

if(isset($_POST["transaction_id"]))
{
 
 $statement = $connection->prepare(
  "DELETE FROM transactions WHERE id = :id"
 );
 $result = $statement->execute(
  array(
   ':id' => $_POST["transaction_id"]
  )
 );
 
 if(!empty($result))
 {
  echo 'Data Deleted';
 }
}

?>
   