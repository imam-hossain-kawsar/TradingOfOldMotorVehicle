<?php
session_start();
$db = mysqli_connect("localhost", "root", "", "tomvs");

if($db === false){

    die("ERROR: Could not connect. " . mysqli_connect_error());

}

// Escape all $_POST variables to protect against SQL injections
$first_name = mysqli_real_escape_string($db, $_REQUEST['firstname']);
$last_name = mysqli_real_escape_string($db, $_REQUEST['lastname']);
$user_name = mysqli_real_escape_string($db, $_REQUEST['username']);
$email = mysqli_real_escape_string($db, $_REQUEST['email']);
$address = mysqli_real_escape_string($db,$_REQUEST['address']);
$mobile = mysqli_real_escape_string($db,$_REQUEST['mobile']);
$password =password_hash($_REQUEST['password'], PASSWORD_BCRYPT);
$hash = md5(rand(0,1000));
$hash = substr($hash, 0, 60);
      
// Check if user with that email already exists
$sql1 = "SELECT * FROM users WHERE email='$email'";
$result = mysqli_query($db, $sql1);

// We know user email exists if the rows returned are more than 0
if ( $result->num_rows > 0 ) {
    
    $_SESSION['message'] = 'User with this email already exists!';
    header("location: error_final.php");
    
}
else { // Email doesn't already exist in a database, proceed...

    // active is 0 by DEFAULT (no need to include it here)
    $sql = "INSERT INTO users (first_name, last_name, user_name,email,address,mobile,password,hash)
    VALUES ('$first_name', '$last_name','$user_name' ,'$email', '$address', '$mobile', '$password', '$hash')";


    // Add user to the database
    if ( mysqli_query($db, $sql)){

		$_SESSION['first_name'] = $first_name;
		$_SESSION['last_name'] = $last_name;
		$_SESSION['email'] = $email;
        $_SESSION['active'] = 0; //0 until user activates their account with verify.php
        $_SESSION['logged_in'] = true; // So we know the user has logged in
        $_SESSION['message'] =
                
                 "Confirmation link has been sent to $email, please verify
                 your account by clicking on the link in the message!";

        // Send registration confirmation link (verify.php)
        $to      = $email;
        $subject = 'Account Verification ( tomvs.com )';
        $message_body = '
        Hello '.$first_name.',

        Thank you for signing up!

        Please click this link to activate your account:

        http://localhost/test/verify_final.php?email='.$email.'&hash='.$hash;  

        mail( $to, $subject, $message_body );

        header("location: profile_final.php"); 

    }

    else {
        $_SESSION['message'] = 'Registration failed!';
        header("location: error_final.php");
    }

}
?>