<?php
include('db.php');
include('transactionfunction.php');
if(isset($_POST["operation"]))
{
	$trnx_id = "trnx-".rand(1,10000);
	$date = date('Y/m/d H:i:s');
	
 if($_POST["operation"] == "Add")
 {
	
	$statement = $connection->prepare("
		   INSERT INTO transactions (transaction_id, seller_id,customer_name,product_id,address,quantity,price,status,time) 
		   VALUES (:trnx_id,:seller_id,:customer_name,:product_id,:address,:quantity,:price,:status, :system_time)
		  ");
		  $result = $statement->execute(
		   array(
			':trnx_id' => $trnx_id,
			':seller_id' => $_POST["seller_id"],
			':customer_name' => $_POST["customer_name"],
			':product_id' => $_POST["product_id"],
			':address' => $_POST["customer_address"],
			':quantity' => $_POST["quantity"],
			':price' => $_POST["price"],
			':status' => $_POST["status"],
			':system_time' => $date
		   )
		  );
		  if(!empty($result))
		  {
		   echo 'Data Inserted';
		  }
}
	 if($_POST["operation"] == "Edit")
	 {
			$statement = $connection->prepare(
				"UPDATE transactions 
				SET seller_id = :seller_id,
				customer_name = :customer_name,
				product_id = :product_id,
				address = :customer_address,
				quantity = :quantity,
				price = :price,
				status = :status, 
				WHERE id = :id
				"
			   );
			   $result = $statement->execute(
				array(
				 ':seller_id' => $_POST["seller_id"],
				 ':customer_name' => $_POST["customer_name"],
				 ':product_id' => $_POST["product_id"],
				 ':customer_address' => $_POST["customer_address"],
				 ':quantity' => $_POST["quantity"],
				 ':price' => $_POST["price"],
				 ':status' => $_POST["status"],
				 ':id' => $_POST["transaction_id"]
				 
				)
			   );
			   if(!empty($result))
			   {
				echo 'Data Updated';
			   }else{
				   echo 'Data not updated';
			   }
			  }	 
		 }
	  
	

?>
   