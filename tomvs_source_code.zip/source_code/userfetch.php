<?php
include('db.php');
include('userfunction.php');
$query = '';
$output = array();
$query .= "SELECT * FROM users ";
if(isset($_POST["search"]["value"]))
{
 $query .= 'WHERE first_name LIKE "%'.$_POST["search"]["value"].'%" ';
 $query .= 'OR last_name LIKE "%'.$_POST["search"]["value"].'%"';
 $query .= 'OR user_name LIKE "%'.$_POST["search"]["value"].'%"';
 $query .= 'OR email LIKE "%'.$_POST["search"]["value"].'%"';
 $query .= 'OR address LIKE "%'.$_POST["search"]["value"].'%"';
 $query .= 'OR mobile LIKE "%'.$_POST["search"]["value"].'%"';
 $query .= 'OR active LIKE "%'.$_POST["search"]["value"].'%"';
}

$statement = $connection->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$data = array();
$filtered_rows = $statement->rowCount();
foreach($result as $row)
{
 
 $sub_array = array();
 $sub_array[] = $row["first_name"];
 $sub_array[] = $row["last_name"];
 $sub_array[] = $row["user_name"];
 $sub_array[] = $row["email"];
 $sub_array[] = $row["address"];
 $sub_array[] = $row["mobile"];
 $sub_array[] = $row["active"];
 $data[] = $sub_array;
}
$output = array(
 "draw"    => intval($_POST["draw"]),
 "recordsTotal"  =>  $filtered_rows,
 "recordsFiltered" => get_total_all_records(),
 "data"    => $data
);
echo json_encode($output);
?>