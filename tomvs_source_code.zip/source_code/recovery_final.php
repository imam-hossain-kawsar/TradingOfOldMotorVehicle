<?php 
/* Reset your password form, sends reset.php password link */

session_start();
$db = mysqli_connect("localhost", "root", "", "tomvs");

if($db === false){

    die("ERROR: Could not connect. " . mysqli_connect_error());

}


// Check if form submitted with method="post"  
    $email = mysqli_real_escape_string($db,$_REQUEST['email']);
    $sql1 = "SELECT * FROM users WHERE email='$email'";
    $result = mysqli_query($db, $sql1);

    if ( $result->num_rows == 0 ) // User doesn't exist
    { 
        $_SESSION['message'] = "User with that email doesn't exist!";
        header("location: error_final.php");
    }
    else { // User exists (num_rows != 0)

        $user = $result->fetch_assoc(); // $user becomes array with user data
        
        $email = $user['email'];
		$_SESSION['email'] = $email;
        $hash = $user['hash'];
        $first_name = $user['first_name'];

        // Session message to display on success.php
        $_SESSION['message'] = "<p>Please check your email <span>$email</span>"
        . " for a confirmation link to complete your password reset!</p>";

        // Send registration confirmation link (reset.php)
        $to      = $email;
        $subject = 'Password Reset Link ( tomvs.com )';
        $message_body = '
        Hello '.$first_name.',

        You have requested password reset!

        Please click this link to reset your password:

        http://localhost/test/reset_password.php?email='.$email.'&hash='.$hash;  

        mail($to, $subject, $message_body);

        header("location: success.php");
  }

?>
