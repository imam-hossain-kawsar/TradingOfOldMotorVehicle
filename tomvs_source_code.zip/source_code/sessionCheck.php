<?php
	session_start();
	if((isset($_SESSION['first_name'])) and ($_SESSION['email']=="tomvsbsse8@gmail.com" ) and $_SESSION['active']==1){
		header("location: admin.php");
	}
	elseif((isset($_SESSION['first_name'])) and ($_SESSION['email']!="tomvsbsse8@gmail.com" ) and $_SESSION['active']==1){
		header("location: viewindex.php");
	}
	else{
		header("location: common_message.php");
	}



?>