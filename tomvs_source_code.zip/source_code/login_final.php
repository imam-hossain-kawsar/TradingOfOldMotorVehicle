<?php
session_start();
$db = mysqli_connect("localhost", "root", "", "tomvs");

if($db === false){

    die("ERROR: Could not connect. " . mysqli_connect_error());

}

$email = mysqli_real_escape_string($db, $_REQUEST['email']);
//$password = mysqli_real_escape_string($db, $_REQUEST['password']);
$query = "SELECT * FROM users WHERE email='$email'";
$results = mysqli_query($db, $query);
$row=mysqli_fetch_assoc($results);

if ( $results->num_rows == 0 ){ // User doesn't exist
    $_SESSION['message'] = "User with that email doesn't exist!";
    header("location: error_final.php");
}
elseif($results->num_rows ==1){ // User exists
    $password1 = $row["password"];
	
        if(password_verify($_REQUEST['password'], $password1)){
            
			$_SESSION['first_name'] = $row['first_name'];
			$_SESSION['last_name'] = $row['last_name'];
			$_SESSION['email'] = $row['email'];
			$_SESSION['mobile'] = $row['mobile'];
			$_SESSION['i'] = 1;
			$_SESSION['active'] = $row['active'];
			header("location: sessionCheck.php");
			
        
        
        
        $_SESSION['active'] = $row['active'];
        
        // This is how we'll know the user is logged in
        $_SESSION['logged_in'] = true;
       

      }  // header("location: profile_final.php");
	  else{
		  header("location: login.php");
	  }
    }
    
?>

