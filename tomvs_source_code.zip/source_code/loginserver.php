<?php
    $db = mysqli_connect("localhost", "root", "", "tomvs");

    if($db === false){
    
        die("ERROR: Could not connect. " . mysqli_connect_error());
    
    }

    $email = mysqli_real_escape_string($db, $_REQUEST['email']);
    $password = mysqli_real_escape_string($db, $_REQUEST['password']);
    $query = "SELECT * FROM users WHERE email='$email' AND password='$password'";
	$results = mysqli_query($db, $query);
    $subject = "you logged in TOMVS.";
    $txt = "Here you can now perform administrative work.";
    if ( ($results->num_rows) == 0 ){ 
       
      
        // $_SESSION['message'] = "User with that email doesn't exist!";
       header("location: loginerrormessage.php");
    }
    elseif(($results->num_rows) == 1){
       //mail($email,$subject,$txt);

       

        if($email == "tomvsbsse8@gmail.com"){
            header("location: admin.php");  
        }
        else{
            header("location: viewindex.php");
        }
         
    }
    else{
        echo "You have entered wrong password. Try again!!";
    }
    mysqli_close($db);
?>