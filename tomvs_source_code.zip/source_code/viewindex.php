<?php
session_start();
$connect = mysqli_connect("localhost", "root", "", "tomvs");
$tab_query = "SELECT * FROM category ORDER BY category_id ASC";
$tab_result = mysqli_query($connect, $tab_query);
$tab_menu = '';
$tab_content = '';
$tab_content_car='';
$tab_content_bike='';
$tab_content_equipment='';
$i = 0;
$value = 0;
$value = $value;
while($row = mysqli_fetch_array($tab_result))
{
 if($i == 0)
 {
  $tab_menu .= '
   <li ><a style="border-left: none; color:white;" href="#'.$row["category_id"].'" data-toggle="tab">'.$row["category_name"].'</a></li>
  ';
  $tab_content .= '
   <div id="'.$row["category_id"].'" class="tab-pane fade in active">
  ';
  
 }
 else
 {
  $tab_menu .= '
   <li><a style="border-left: none; color:white;" href="#'.$row["category_id"].'" data-toggle="tab">'.$row["category_name"].'</a></li>
  ';
  $tab_content .= '
   <div id="'.$row["category_id"].'" class="tab-pane fade">
  ';
  
 }
 

if($row["category_name"] == "car"){
	
	
	$results_per_page = 15;
    $product_query = "SELECT * FROM cars" ;
    $product_result = mysqli_query($connect, $product_query);
	$number_of_results = mysqli_num_rows($product_result);
	$number_of_pages = ceil($number_of_results/$results_per_page);
	if (!isset($_GET['page'])) {
	$page = 1;
	} else {
	  $page = $_GET['page'];
	}
	$this_page_first_result = ($page-1)*$results_per_page;
	$sql='SELECT * FROM cars LIMIT ' . $this_page_first_result . ',' .  $results_per_page;
	$result = mysqli_query($connect, $sql);
    while($sub_row = mysqli_fetch_array($result))
    {
        $tab_content .= '
            <div class="col-md-3 col-sm-6" style="margin-bottom:50px; height:350px;" >
                <div  id="my-story" class="oww fadeInUp" >
                    <a href="#"><img src="car/'.$sub_row["image"].'" alt=""  style="width:255px; height:230px" class="wow  fadeInUp"/></a><br>
                    <font style="font-size:150%; color:white;" > '.$sub_row["brand_name"]. ' '.$sub_row["model_name"].' &nbsp;&nbsp;&nbsp;<a href="#"><span style="font-size:200%;color:red;"></span></a> </font><br>
                    <font style="font-size:150%; color:white;" >&#x9f3; '.$sub_row["price"]. ' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><span style="font-size:200%;color:white;">&hearts;</span></a> </font> 
                </div>
            </div>
			
        ';
    }
	
	
    $tab_content .= '<div style="clear:both"></div></div>';
    $i++;
	
 
}
 elseif($row["category_name"] == "bike"){
	 $results_per_page = 1;
    $product_query = "SELECT * FROM bikes ";
    $product_result = mysqli_query($connect, $product_query);
	$number_of_results = mysqli_num_rows($product_result);
	$number_of_pages = ceil($number_of_results/$results_per_page);
	if (!isset($_GET['page'])) {
	$page = 1;
	} else {
	  $page = $_GET['page'];
	}
	$this_page_first_result = ($page-1)*$results_per_page;
	$sql='SELECT * FROM bikes LIMIT ' . $this_page_first_result . ',' .  $results_per_page;
	$result = mysqli_query($connect, $sql);
    while($sub_row = mysqli_fetch_array($product_result))
    {
        $tab_content .= '
            <div class="col-md-3 col-sm-6" style="margin-bottom:50px; height:350px;">
                <div id="my-story" class="oww fadeInUp">
                    <a href="#"><img src="bike/'.$sub_row["image"].'" alt=""  style="width:255px; height:230px"/></a><br>
                
					<font style="font-size:150%; color:white;"> '.$sub_row["brand_name"]. ' '.$sub_row["model_name"].' &nbsp;&nbsp;&nbsp;<a href="#"><span style="font-size:200%;color:red;"></span></a> </font><br>
                    <font style="font-size:150%; color:white;">&#x9f3; '.$sub_row["price"]. ' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><span style="font-size:200%;color:white;">&hearts;</span></a> </font>
                    
					</div>
        
            </div>
        ';
    }
    $tab_content .= '<div style="clear:both"></div></div>';
    $i++;
    
 }
 else{
    $product_query = "SELECT * FROM equipments";
    $product_result = mysqli_query($connect, $product_query);
    while($sub_row = mysqli_fetch_array($product_result))
    {
        $tab_content .= '
	
       
        <div class="col-md-3 col-sm-6" style="margin-bottom:50px; height:350px;">
            <div id="my-story" class="oww fadeInUp">
					<a href="#"><img src="equipment/'.$sub_row["image"].'" alt=""  style="width:255px; height:230px; vertical-align:middle;"/></a><br>
					<font style="font-size:150%; color:white;"> '.$sub_row["equipment_name"]. '  &nbsp;&nbsp;&nbsp;<a href="#"><span style="font-size:200%;color:red;"></span></a> </font><br>
                    <font style="font-size:150%; color:white;">&#x9f3; '.$sub_row["unit_price"]. ' &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="#"><span style="font-size:200%;color:white;">&hearts;</span></a> </font>
                                    <br><br><br>
            </div>
    
        </div>
       
     
    
        ';
    }
    $tab_content .= '<div style="clear:both"></div></div>';
    $i++;
 }
}

 /*$product_query = "SELECT * FROM car WHERE category_id = '".$row["category_id"]."'";
 <div class="container story">
    <div class="col-md-4 col-sm-6">
        <div class="my-story">
            <img src="equipmentimages/'.$sub_row["image"].'" alt=""/>
            <h4>price '.$sub_row["unit_price"].'</h4>
        </div>

    </div>
 
 
 </div>
 
 
 
 */
 

?>

<!DOCTYPE html>
<html>
 <head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="media.css">
    <link rel="stylesheet" href="animate.css">
    <link rel="stylesheet" href="global.css">
    <link rel="stylesheet" href="home.css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800" rel="stylesheet">
    <title> TOMVS</title>
    <link rel="stylesheet" href="about.css">
	<link rel="stylesheet" href="slideshow.css">
	<script type="text/javascript" src="wow.min.js">
		
	</script>

	<link rel="shortcut icon" type="image/ico" href="icon5.png"/>

  <style>
    #my-story:hover{
        background: red;
        transition: 0.5s;
		-webkit-transform: scale(1.1);
        -ms-transform: scale(1.1);
        transform: scale(1.1);
    }
    img:hover{
        background:#337ab71f;
		
    }
    
    #my-story{
        text-align:center;
		background-color:#294160;
        
    }
   
	aside{
		margin: 0;
		padding: 0;
		border: 0;
		font-size: 100%;
		font: inherit;
		vertical-align: baseline;
		display: block;
		color:white;
	}
	.sticky {
	  position: sticky;
	  top: 0;
	  width: 100%;
	  
	  
	}
		
	  a{
		  text-decoration:none;
	  }
	  #myBtn {
		  display: none;
		  position: fixed;
		  bottom: 20px;
		  right: 30px;
		  z-index: 99;
		  font-size: 18px;
		  border: none;
		  outline: none;
		  background-color: red;
		  color: white;
		  cursor: pointer;
		  padding: 15px;
		  border-radius:4px;
		}

		#myBtn:hover {
		  background-color: #555;
		}
		
		#f0f9f8
		
		
		
  </style>
  <style> 
	input[type=text] {
		width: 1000px;
		box-sizing: border-box;
		border: 2px solid #ccc;
		border-radius: 4px;
		font-size: 16px;
		background-color: white;
		background-image: url('Search.png');
		background-position: 10px 10px; 
		background-repeat: no-repeat;
		padding: 12px 20px 12px 40px;
		margin-left:150px;
		-webkit-transition: width 0.4s ease-in-out;
		transition: width 0.4s ease-in-out;
	}

	input[type=text]:focus {
		width: 70%;
	}
</style>
<style>
.wowBack {
  background:#222;
  position:relative; overflow:hidden;
}
.wowWrap div {
  background:#27ae60; 
  display:block;
  width:100%;
  margin:5% 0;
  text-align:center;
  padding-top:20%;
  padding-bottom:20%;
}

.wowWrap {
  width:16.66%;
  float:left;
  padding: 0 .5%;
}

.wowWrap h4{
  position:fixed;
  z-index:200;
  width:100%;
  padding:1% 0% 1% 0%;
  margin:0;
  color:white;  
  font-size:1.35vw;
  background:rgba(22,22,22,.3)
}

.wowWrap div:first-of-type{
  margin-top:25%; }

/*I've assigned class wHighlight to all the animate.css classes that add elements onto the page with delay.  */
.wHighlight {background:#28a !important}


.down {
    transform: rotate(45deg);
    -webkit-transform: rotate(45deg);
}
</style>
<script type="text/javascript">
	new WOW().init();
	smoothScroll.init();
</script>
 </head>
 <body style="background-color:white; ">
	
	<nav class="navbar navbar-inverse  navbar-fixed-top" style="color:white;background-color:#294160; " id="navbar">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">
                     <img src="home.png" alt="" style="width: 50px;position: relative;top: -20px;float: left;margin-left:30px;" />
						<h1 style="color:white;font-size: 30px;float: left;margin-top: -10px;margin-left: 5px;font-weight: bold;" >TOMVS</h1>

                    </a>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-left">
                        <?php
                            echo $tab_menu;
                        ?>
						<li><a href="sellformsession.php">
							<font style="font-size:20px; color:#d4d6e5;"> Sell Your Old Vehicles</font>
						</a></li>

						
						<li><a href="pre_order_session.php">
							<font style="font-size:20px; color:#d4d6e5;"> Pre-Order</font>
						</a></li>
					<?php
						if(!isset($_SESSION['first_name'])){
						$register = '&nbsp;
							<li><a href="signup.php">
							<i class="fa fa-user" aria-hidden="true" style="color:white;font-size:20px; ">register</i>&nbsp;
							</a><li>
						';
						echo $register;
						
						}
						?>
						
						<?php
						if(!isset($_SESSION['first_name'])){
						$login = '&nbsp;
							<li><a href="login.php">
							<i class="fa fa-user" aria-hidden="true" style="color:white;font-size:20px; ">login</i>&nbsp;
							</a><li>
						';
						echo $login;
						
						}
						?>
						
						
						<li><a href="#" class="btn btn-danger btn-sm" style="color:white;">
							  <span class="glyphicon glyphicon-shopping-cart"><b>Cart<?php echo "(".$value.")"  ?></span> 
						</a></li>
						<?php
							if(isset($_SESSION['first_name'])){
								$first_name = $_SESSION['first_name'];
								$welcome = '<font style="color:white;font-size:20px;"> &nbsp;&nbsp;&nbsp;welcome</font>';
								echo $welcome.",".$first_name;
								$logout = '
									<li><a href="logout.php"><i  style="color:red;font-size:20px; ">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;logout</i></a></li>
								';
								echo $logout;
							}
							
						?>
						
						
                    </ul>
                </div>
				
            </div>
			
        </nav>
		<br><br><br><br><br>
		
		<div class="button_box2">
			<form action="searchindex.php" method="post">
			  <input type="text" name="search" placeholder="Search by BrandName......">
			  
			</form>
		</div>
		<br>
		<div style="height:50px; background-color:#294160;">
			<p style="color:white; align:center;margin-left:130px;"><b>Helpline(Contact):&nbsp;&nbsp;<i class="fa fa-mobile-phone" style="font-size:40px;color:white;"></i>&nbsp;&nbsp; 01521-435856
				&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-envelope-o" style="font-size:30px;color:white"></i>&nbsp;&nbsp;tomvsbsse8@gmail.com
			</p>
		</div>
  <br><br><br>
  
	<button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fa fa-arrow-circle-up"></i>Top</button>
	
	
	
	
	 <div style="background-color:white; height:300px;" class="oww fadeInUp" >
		<div class="site-aim" style="padding-left:150px;padding-top:70px;margin:auto;">
            <h1 style="color:#294160;font-face:BringHeart-regular " class="wow fadeInUp" >Let's make your dream true !</h1>
            <p style="color:black; font-face:BringHeart-regular " class="wow fadeInLeft">Start your journey with us & achieve your goals</p>
			
        </div>
		
	  
	  </div>
	  <br><br>
	  <div style="background-color:white; height:100px;">
		<i class="fa fa-chevron-down" style="font-size:48px;color:#294160;margin-left:600px;"></i>
	  </div>
		
	  
  <br><br><br><br><br><br><br>
 
  <div class="container" >

   
   <br/>
   
  <div class="tab-content">
   <br />
   
   
	<?php
		
		echo $tab_content;
		
		
   ?>
  
   
  </div>
	
  
  </div>
  <br><br><br><br><br><br><br><br><br>
  
  
  <div style="background-color:#294160; padding:0;margin:0; " class="container-fluid" >
  <br>
 
	<div class="row">
		<div class="col-sm-12">
		 <h4 style="text-align:center;color:white;" class="oww fadeInLeft">Contact us</h4>
		</div>
	
	</div>
	<div class="row">
		
			
	  <div class="col-sm-4 col-md-4" style="color:white; margin-left:5px;">
	
		<p class="oww fadeInUp">Imam Hossain Kawsar<br>Institute of Information Technology<br>University of Dhaka<br>mobile:01521-435856<br>email:bsse0816@iit.du.ac.bd</p>

	  </div>
	  <div class="col-sm-4 col-md-4" style="color:white;margin-left:5px;">
		
		<p>Ibrahim Khalil<br>Institute of Information Technology<br>University of Dhaka<br>mobile:<br>email:bsse0804@iit.du.ac.bd</p>
	  </div>
	   <div  style="color:white;margin-left:5px;float:left;" >
	
		<p>Nadia Nahar<br>Lecturer<br>Institute of Information Technology<br>University of Dhaka</p>

	  </div>
	</div>

		<div class="row" class="owwWrap">
			<div class="col-sm-12">
			<br><br><br><br><br>
				<p style="color:white;text-align:center;vertical-align:middle;" >All rights reserved </p>

			</div>
		
		</div>
	  
  
  </div>
	
	<script>
		window.onscroll = function() {myFunction()};

		var header = document.getElementById("navbar");
		var sticky = header.offsetTop;

		function myFunction() {
		  if (window.pageYOffset >= sticky) {
			header.classList.add("sticky");
		  } else {
			header.classList.remove("sticky");
		  }
		}
	</script>
	<script>
		// When the user scrolls down 20px from the top of the document, show the button
		window.onscroll = function() {scrollFunction()};

		function scrollFunction() {
			if (document.body.scrollTop > 800 || document.documentElement.scrollTop > 800) {
				document.getElementById("myBtn").style.display = "block";
			} else {
				document.getElementById("myBtn").style.display = "none";
			}
		}

		// When the user clicks on the button, scroll to the top of the document
		function topFunction() {
			document.body.scrollTop = 0;
			document.documentElement.scrollTop = 0;
		}
	</script>

	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.20.4/TweenMax.min.js"></script>
	<script src="animate-scroll.js"></script>
	<script type="text/javascript">
		$(document).animateScroll();
	</script>


	</body>
</html>

