
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Create your free account and get login, access everything which you want.">
        <meta name="keywords" content="">

        <link rel="shortcut icon" type="image/ico" href="icon5.png"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="animate.css">
        <link rel="stylesheet" href="global.css">
        <link rel="stylesheet" href="login.css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800" rel="stylesheet">
        <title> Log in</title>
        <script>var base_url = "";</script>
        <link href="about.css" rel="stylesheet" type="text/css"/>







      


    </head>
    <body style="background-color: rgba(27, 97, 255, 0.12);">
	<nav class="navbar navbar-inverse navbar-fixed-top" style="background-color:#294160; color:white;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">
                        <img src="icon5.png" alt="" style="width: 70px;position: relative;top: -25px;float: left;" />
                        <h1 style="font-size: 30px;float: left;margin-top: 0px;margin-left: 5px;font-weight: bold;  color:white;">TOMVS</h1>
                    </a>
                </div>
                
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                       
                    </ul>
                </div>
            </div>
        </nav>
       


<div class="container">
    
    <div class="col-md-2">
	
		
	</div>
    <div class="col-md-8">
		<br><br><br><br>
	
        <form  action="login_final.php" method="post" class="my_form"   autocomplete="off">
            <div id="login-response" class="animated bounceInDown"></div>
            <h1 class="text-center" style="text-shadow:0 0 8px #fd0202; color:white;">Log In </h1>
            <div class="login-form">
                <div class="control-group">
                    <input style="color:white;" type="email" class="login-field form-control" value="" placeholder="Email" id="login-username" name="email" required>
                    <label class="login-field-icon fui-user" for="login-email"></label>
                </div>

                <div class="control-group">
                    <input style=" color:white;" type="password" class="login-field form-control" value="" placeholder="Password" id="login-password" name="password" required>
                    <label class="login-field-icon fui-lock" for="login-password"></label>
                </div>
                <br>
                <input style="color:black; font-size:16px;" type="submit" value="log in" class="btn btn-primary col-xs-12 btn-submit" name="login" > 

                <br> <a class="login-link" href="forgot-password.html">Forget your password?</a>
            </div><br>

        </form>
    </div>
    <div class="col-md-2"></div>
    
   
  
</div>

<br><br><br><br>





<!--js scripts -->
            <script src='https://code.jquery.com/jquery-2.2.4.min.js'></script>
            <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
            <script src='login.js'></script>
    </body>
</html>
