<?php
	session_start();
	
	$j = $_SESSION['i'];
	if($j==1 and $_SESSION['email']=="tomvsbsse8@gmail.com"){
		$status = 'true';
		
	}
	else{
		header("location:common_message.php");
	}

?>



<html>
 <head>
  <title>USER</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>  
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link rel="shortcut icon" type="image/ico" href="icon5.png"/>       
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="global.css">
  <link rel="stylesheet" href="forgot_password.css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800" rel="stylesheet">
  <link href="about.css" rel="stylesheet" type="text/css"/>
        
  <style>
    .tableinfo{
        color:#294160;
    }
    label{
        color: #294160;
    }
    
  </style>


 </head>
 <body style="background-color:#9ebfb3;color:white;">
 <div class="experiment" style="background-color:#66757F; height:5px;">
			
		</div>
  <nav class="navbar navbar-inverse" style="background-color:#294160; color:white;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">
                        <img src="icon5.png" alt="" style="width: 70px;position: relative;top: -25px;float: left;" />
                        <h1 style="font-size: 30px;float: left;margin-top: 0px;margin-left: 5px;font-weight: bold;">TOMVS</h1>
                    </a>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                       
						 <li><a href="carindex.php" style=" border-left: none; color:white;">CAR</a></li>
						<li><a href="bikeindex.php" style=" color:white;">BIKE</a></li>
						<li><a href="equipmentindex.php" style=" color:white;">EQUIPMENT</a></li>
						<li><a href="transactionindex.php" style=" color:white;">TRANSACTION</a></li>
						<li><a href="customerlistindex.php" style=" color:white;">CUSTOMERLIST</a></li>
						<li><a href="advertisementlist.php" style=" color:white;">ADVERTISEMENT</a></li>
						<?php
							if(isset($_SESSION['first_name'])){
								$first_name = $_SESSION['first_name'];
								$welcome = '<font style="color:white;font-size:20px;"> welcome</font>';
								echo $welcome.",".$first_name;
								$logout = '
									<li><a href="logout.php"><i  style="color:red;font-size:20px; ">logout</i></a></li>
								';
								echo $logout;
							}
							
						?>
						
						
                    </ul>
                </div>
            </div>
        </nav>

  <div class="container box">
   <h1 align="center" style="color:#294160;">Customer List</h1>
   <br />
   <div class="table-responsive">
    <br />
    <div align="right">
    </div>
    <br /><br />

    <table id="user_data" class="table table-bordered table-default" style="color:#294160;">
     <thead>
      <tr>
       <th width="16%" class = "tableinfo">first_name</th>
       <th width="14%" class = "tableinfo">last_name</th>
       <th width="14%" class = "tableinfo">user_name</th>
       <th width="14%" class = "tableinfo">email</th>
       <th width="14%" class = "tableinfo">address</th>
       <th width="14%" class = "tableinfo">mobile</th>
       <th width="14%" class = "tableinfo">active</th>
      </tr>
     </thead>
    </table>
    
   </div>
  </div>
  <script type="text/javascript" language="javascript">
	var dataTable = $('#user_data').DataTable({
  "processing":true,
  "serverSide":true,
  "order":[],
  "ajax":{
   url:"userfetch.php",
   type:"POST"
  },
  "columnDefs":[
  ],

 });
  </script>



</body>
</html>




   
    