<?php
	include('db.php');
	include('transactionfunction.php');
	if(isset($_POST["transaction_id"]))
	{
		 $output = array();
		 $statement = $connection->prepare(
		  "SELECT * FROM transactions 
		  WHERE id = '".$_POST["transaction_id"]."' 
		  LIMIT 1"
	 );
		 $statement->execute();
		 $result = $statement->fetchAll();
	 foreach($result as $row)
	 {
		  $output["seller_id"] = $row["seller_id"];
		  $output["customer_name"] = $row["customer_name"];
		  $output["product_id"] = $row["product_id"];
		  $output["customer_address"] = $row["address"];
		  $output["quantity"] = $row["quantity"];
		  $output["price"] = $row["price"];
		  $output["status"] = $row["status"];
	 }
	 echo json_encode($output);
	}
?>