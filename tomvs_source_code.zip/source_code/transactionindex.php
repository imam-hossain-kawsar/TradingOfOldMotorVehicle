<?php
	session_start();
	
	$j = $_SESSION['i'];
	if($j==1 and $_SESSION['email']=="tomvsbsse8@gmail.com"){
		$status = 'true';
		
	}
	else{
		header("location:common_message.php");
	}

?>



<html>
 <head>
  <title>TRANSACTION</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>  
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link rel="shortcut icon" type="image/ico" href="icon5.png"/>       
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="global.css">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800" rel="stylesheet">
  <link href="about.css" rel="stylesheet" type="text/css"/>
        
  <style>
    label{
        color: #294160;
    }
  </style>


 </head>
 <body style="background-color:#9ebfb3;color:white;">
 <div class="experiment" style="background-color:#66757F; height:5px;">
			
		</div>
  <nav class="navbar navbar-inverse" style="background-color:#294160; color:white;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">
                        <img src="icon5.png" alt="" style="width: 70px;position: relative;top: -25px;float: left;" />
                        <h1 style="font-size: 30px;float: left;margin-top: 0px;margin-left: 5px;font-weight: bold;">TOMVS</h1>
                    </a>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                       
						 <li><a href="carindex.php" style=" border-left: none; color:white;">CAR</a></li>
						<li><a href="bikeindex.php" style=" color:white;">BIKE</a></li>
						<li><a href="equipmentindex.php" style=" color:white;">EQUIPMENT</a></li>
						<li><a href="transactionindex.php" style=" color:white;">TRANSACTION</a></li>
						<li><a href="customerlistindex.php" style=" color:white;">CUSTOMERLIST</a></li>
						<li><a href="equipmentindex.php" style=" color:white;">ADVERTISEMENT</a></li>
						<?php
							if(isset($_SESSION['first_name'])){
								$first_name = $_SESSION['first_name'];
								$welcome = '<font style="color:white;font-size:20px;"> welcome</font>';
								echo $welcome.",".$first_name;
								$logout = '
									<li><a href="logout.php"><i  style="color:red;font-size:20px; ">logout</i></a></li>
								';
								echo $logout;
							}
							
						?>
						
                    </ul>
                </div>
            </div>
        </nav>





  <div class="container box">
   <h1 align="center" style="color:#294160;">TRANSACTION TABLE</h1>
   <br />
   <div class="table-responsive">
    <br />
    <div align="right">
     <button type="button" id="add_button" data-toggle="modal" data-target="#transactionModal" class="btn btn-info btn-lg">Add</button>
    </div>
    <br /><br />

    <table id="transaction_data" class="table table-bordered table-default" style="color:#294160;">
     <thead>
      <tr>
       <th width="20%" style="color:#294160;">transaction-ID</th>
       <th width="8%" style="color:#294160;">Seller-ID</th>
       <th width="13%" style="color:#294160;">Customer-name</th>
	   <th width="8%" style="color:#294160;">Product-ID</th>
       <th width="13%" style="color:#294160;">Address</th>
       <th width="8%" style="color:#294160;">quantity</th>
       <th width="8%" style="color:#294160;">price</th>
       <th width="8%" style="color:#294160;">status</th>
       <th width="8%" style="color:#294160;">date&time</th>
       <th width="8%" style="color:#294160;">Edit</th>
       <th width="8%" style="color:#294160;">Delete</th>
      </tr>
     </thead>
    </table>
    
   </div>
  </div>
  

<div id="transactionModal" class="modal fade">
 <div class="modal-dialog">
  <form method="post" id="transaction_form" enctype="multipart/form-data">
   <div class="modal-content">
    <div class="modal-header">
     <button type="button" class="close" data-dismiss="modal">&times;</button>
     <h4 class="modal-title" style="color:black;">Add Transaction</h4>
    </div>
    <div class="modal-body">
     <label style="color:black;">Enter Seller ID</label>
     <input type="text" name="seller_id" id="seller_id" class="form-control"/>
     <br />
     <label style="color:black;">Enter Customer Name</label>
     <input type="text" name="customer_name" id="customer_name" class="form-control" />
     <br />

	 <label style="color:black;">Enter Product ID</label>
     <input type="text" name="product_id" id="product_id" class="form-control" />
     <br />
	 
	 <label style="color:black;">Enter Customer Address</label>
     <input type="text" name="customer_address" id="customer_address" class="form-control" />
     <br />
	 
	 <label style="color:black;">Enter Quantity</label>
     <input type="text" name="quantity" id="quantity" class="form-control" />
     <br />
	 
	 <label style="color:black;">Enter Price</label>
     <input type="text" name="price" id="price" class="form-control" />
     <br />
     
	 <label style="color:black;">Enter Payment Status</label>
     <input type="text" name="status" id="status" class="form-control" />
     <br />
	 
    </div>
    <div class="modal-footer">
     <input type="hidden" name="transaction_id" id="transaction_id" />
     <input type="hidden" name="operation" id="operation" />
     <input type="submit" name="action" id="action" class="btn btn-success" value="Add" />
     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
   </div>
  </form>
 </div>
</div>





<script type="text/javascript" language="javascript" >
$(document).ready(function(){
 $('#add_button').click(function(){
  $('#transaction_form')[0].reset();
  $('.modal-title').text("Add Transaction");
  $('#action').val("Add");
  $('#operation').val("Add");
 });
 
 var dataTable = $('#transaction_data').DataTable({
  "processing":true,
  "serverSide":true,
  "order":[],
  "ajax":{
   url:"transactionfetch.php",
   type:"POST"
  },
  "columnDefs":[
   {
    "targets":[9,10],
    "orderable":false,
   },
  ],

 });

 $(document).on('submit', '#transaction_form', function(event){
  event.preventDefault();
  var seller_id = $('#seller_id').val();
  var customer_name = $('#customer_name').val();
  var product_id = $('#product_id').val();
  var customer_address = $('#customer_address').val();
  var quantity = $('#quantity').val();
  var status = $('#status').val();
  var price = $('#price').val();
  if(seller_id != '' && customer_name != '' && product_id !='' && quantity != '' && price != '' && status!='')
  {
   $.ajax({
    url:"transactioninsert.php",
    method:'POST',
    data:new FormData(this),
    contentType:false,
    processData:false,
    success:function(data)
    {
     alert(data);
     $('#transaction_form')[0].reset();
     $('#transactionModal').modal('hide');
     dataTable.ajax.reload();
    }
   });
  }
  else
  {
   alert("All Fields are Required");
  }
 });
 
 $(document).on('click', '.update', function(){
  var transaction_id = $(this).attr("id");
  $.ajax({
   url:"transactionfetch_single.php",
   method:"POST",
   data:{transaction_id:transaction_id},
   dataType:"json",
   success:function(data)
   {
    $('#transactionModal').modal('show');
    $('#seller_id').val(data.seller_id);
    $('#customer_name').val(data.customer_name);
    $('#product_id').val(data.product_id);
    $('#customer_address').val(data.customer_address);
    $('#quantity').val(data.quantity);
    $('#status').val(data.status);
    $('#price').val(data.price);
    $('.modal-title').text("Edit Transaction");
    $('#transaction_id').val(transaction_id);
    $('#action').val("Edit");
    $('#operation').val("Edit");
   }
  })
 });
 
 $(document).on('click', '.delete', function(){
  var transaction_id = $(this).attr("id");
  if(confirm("Are you sure you want to delete this?"))
  {
   $.ajax({
    url:"transactiondelete.php",
    method:"POST",
    data:{transaction_id:transaction_id},
    success:function(data)
    {
     alert(data);
     dataTable.ajax.reload();
    }
   });
  }
  else
  {
   return false; 
  }
 });
 
 
});
</script>

</body>
</html>




   
    