<?php
include('db.php');
include('advertisementlistfunction.php');
$query = '';
$output = array();
$query .= "SELECT * FROM advertisementproduct ";
if(isset($_POST["search"]["value"]))
{
 $query .= 'WHERE customer_name LIKE "%'.$_POST["search"]["value"].'%" ';
 $query .= 'OR mobile LIKE "%'.$_POST["search"]["value"].'%"';
 $query .= 'OR brand_name LIKE "%'.$_POST["search"]["value"].'%"';
 $query .= 'OR model_name LIKE "%'.$_POST["search"]["value"].'%"';
 $query .= 'OR price LIKE "%'.$_POST["search"]["value"].'%"';
 $query .= 'OR price_condition LIKE "%'.$_POST["search"]["value"].'%"';
 $query .= 'OR fuel LIKE "%'.$_POST["search"]["value"].'%"';
}
if(isset($_POST["order"]))
{
 $query .= 'ORDER BY '.$_POST['order']['0']['column'].' '.$_POST['order']['0']['dir'].' ';
}
else
{
 $query .= 'ORDER BY id DESC ';
}
if($_POST["length"] != -1)
{
 $query .= 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}
$statement = $connection->prepare($query);
$statement->execute();
$result = $statement->fetchAll();
$data = array();
$filtered_rows = $statement->rowCount();
foreach($result as $row)
{
 
 $image = '';
 if($row["image"] != '')
 {
  $image = '<img src="advertisementproduct_image/'.$row["image"].'" class="img-thumbnail" width="200" height="80" />';
 }
 else
 {
  $image = '';
 }
 
 $sub_array = array();
 $sub_array[] = $row["customer_name"];
 $sub_array[] = $row["mobile"];
 $sub_array[] = $row["advertisement_id"];
 $sub_array[] = $row["product_type"];
 $sub_array[] = $row["brand_name"];
 $sub_array[] = $row["model_name"];
 $sub_array[] = $row["original_buying_year"];
 $sub_array[] = $row["fuel"];
 $sub_array[] = $row["capacity"];
 $sub_array[] = $row["price"];
 $sub_array[] = $row["price_condition"];
 $sub_array[] = $row["time"];
 $sub_array[] = $row["color"];
 $sub_array[] = $image;
 $data[] = $sub_array;
}
$output = array(
 "draw"    => intval($_POST["draw"]),
 "recordsTotal"  =>  $filtered_rows,
 "recordsFiltered" => get_total_all_records(),
 "data"    => $data
);
echo json_encode($output);
?>