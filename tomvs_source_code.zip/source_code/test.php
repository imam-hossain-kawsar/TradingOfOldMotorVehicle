<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">

<nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">
                        <img src="icon5.png" alt="" style="width: 40px;position: relative;top: -10px;float: left;" />
                        <h1 style="font-size: 20px;float: left;margin-top: 0px;margin-left: 5px;font-weight: bold; text-shadow:0 0 8px #fd0202; color:white;">TOMVS</h1>
                    </a>
                </div>
                
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right">
                       
                    </ul>
                </div>
            </div>
        </nav>
 <br><br><br><br><br><br>
	
	<div class="alert alert-warning" role="alert">
		<strong>Warning!</strong>  Your email or password is wrong. Enter a valid email and password!<br>
		<a href="login.php"class="alert-link">TRY AGAIN!! </a>
	</div>

 <!-- <h2>Alerts</h2>
 
	<div class="alert alert-info">
		<strong>Info!</strong> Your email or password is wrong. Enter a valid email and password!
	</div>
 
  <div class="alert alert-success">
    <strong>Success!</strong> This alert box could indicate a successful or positive action.
  </div>
  
  <div class="alert alert-warning">
    <strong>Warning!</strong> This alert box could indicate a warning that might need attention.
  </div>
  <div class="alert alert-danger">
    <strong>Danger!</strong> This alert box could indicate a dangerous or potentially negative action.
  </div>
</div>-->

</body>
</html>




