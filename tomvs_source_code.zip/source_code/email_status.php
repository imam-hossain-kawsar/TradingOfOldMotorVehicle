<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Forgot Password? Enter your email address, and we'll email your password.">
        <meta name="keywords" content="password, forget, forget password, forgot password, paytm forget password recover, iphone, how to, reset password, ios, passcode, reset, gmail ka password bhul gaya hu, forget pin, password reset, recover forgot paytm password, recover password, facebook password recovery, find password, recover lost paytm password, ipad, how, forgotten, unlock, to, ipod touch, ipod, tutorial, howto, forgot, hindi, iphone 6, remove, apple, recover, fix">

        <link rel="shortcut icon" type="image/ico" href="icon5.png"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="global.css">
        <link rel="stylesheet" href="forget_password.css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800" rel="stylesheet">
        <title> Forget Password</title>
        <script>var base_url = "";</script>
        <link href="about.css" rel="stylesheet" type="text/css"/>







      


    </head>
    <body>
            <nav class="navbar navbar-inverse">
                    <div class="container">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="index.php">
                                <img src="icon5.png" alt="" style="width: 70px;position: relative;top: -25px;float: left;" />
                                <h1 style="font-size: 30px;float: left;margin-top: 0px;margin-left: 5px;font-weight: bold; text-shadow:0 0 8px #fd0202; color:white;">TOMVS</h1>
                            </a>
                        </div>
                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="signup.php" style="border-left: none; text-shadow:0 0 8px #fd0202; color:white;">Sign up</a></li>
                                <li><a href="login.php" style="text-shadow:0 0 8px #fd0202; color:white;">Login</a></li>
                                <li class="dropdown">
                                    <a href="#" style="text-shadow:0 0 8px #fd0202; color:white;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                                        <i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                                        <i class="fa fa-dot-circle-o" aria-hidden="true"></i>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li><a href="admin.php"><i class="fa fa-caret-square-o-down" aria-hidden="true"></i> ADMIN PANEL</a></li>
                                        <li><a href="#"><i class="fa fa-envelope-o" aria-hidden="true"></i> Contact us</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </nav>


<div class="container">
   
    <div class="col-md-4" style="margin-top: 100px;">
    </div>

    <div class="col-md-6" style="margin-top: 100px;">
        <h2 style=" text-shadow:0 0 8px #fd0202; color:white;"> use another email. this email is already used</h2>
    </div>
    <div class="col-md-2" style="margin-top: 100px;">
    </div>
</div>
<br><br><br><br><br><br>
<br><br><br>
<br><br><br>

<div class="social-container">
    <h3>Would you like to share with ?</h3>
    <ul class="share-social text-center">
        <li>
            <div class="fb-share-button" data-href="#" data-layout="button" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_self" href=""><i id="social-fb" class="fa fa-facebook fa-2x social"></i></a></div>
        </li>
        <li><a href=""><i id="social-tw" class="fa fa-twitter fa-2x social"></i></a></li>
        <li><a href=""><i id="social-gp" class="fa fa-google fa-2x social"></i></a></li>
    </ul>
</div>







<div class="modal fade" id="sign-up-newlater" style="margin-top: 200px;">
    <div class="modal-dialog sign-up-newlater">

        <div>
            <!--newsletter form-->
            <div class="row">
                <a href="" class="close_it-model" data-dismiss="modal" aria-hidden="true"><i class="fa fa-close"></i></a>
                <h3 style="margin-top: 0;">GET NOTIFIED OF NEW COURSES</h3>

                <p id="newlreponce" style="color: red;font-family: sans-serif;"></p>
                <input type="email" class="form-control col-sm-8" placeholder="Enter your email here" id="news-later-email" name="news-later-email">
                <input type="submit" class="btn" value="subscribe" id="btn-newlatter">
                <p>YOUR EMAIL ADDRESS WILL NEVER BE SHARED</p>
            </div>
            <div class="clearfix"></div>



        </div>
    </div>
</div>




<!--js scripts -->
                <script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    </body>
</html>
