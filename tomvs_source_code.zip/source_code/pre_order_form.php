<?php
	session_start();
	
	$j = $_SESSION['i'];
	if($j==1 and $_SESSION['email']!="tomvsbsse8@gmail.com"){
		$status = 'true';
		
	}
	else{
		include('pre_order_session.php');
	}

?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Buy and Sell your car or bike staying at home">
        <meta name="keywords" content="">

        <link rel="shortcut icon" type="image/ico" href="icon5.png"/>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="global.css">
        <!--<link rel="stylesheet" href="forget_password.css">-->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800" rel="stylesheet">
        <title> Pre-order form</title>
        <link href="about.css" rel="stylesheet" type="text/css"/>
        


    </head>
    <body style="background-color: rgba(27, 97, 255, 0.12);">
        <nav class="navbar navbar-inverse" style="background-color:#294160; color:white;">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="viewindex.php">
                        <img src="icon5.png" alt="" style="width: 70px;position: relative;top: -25px;float: left;" />
                        <h1 style="font-size: 30px;float: left;margin-top: 0px;margin-left: 5px;font-weight: bold; text-shadow:0 0 8px #0255fda6; color:white;">TOMVS</h1>
                    </a>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                </div>
            </div>
        </nav>
        


<div class="container">
<div class="col-md-2"></div>
    <div class="col-md-8">
        <form  action="pre_order_form_manipulation.php" method="post"  class="my_form"  autocomplete="off" style="padding:5px; margin-top:2px;">
            <h1 class="text-center" style="text-shadow:0 0 8px #0255fda6; color:white;">Pre-order Form</h1>
            <h5 class="text-center" style="text-shadow:0 0 8px #0255fda6; color:white;">(Please, fill up the form to complete your order)</h5><br>

            <div class="row">
                <div class="form-group col-xs-12">
                    <label for="customername" class="sr-only">Customer Name</label>
                    <input style="text-shadow:0 0 8px #0255fda6; color:white;" id="customername" class="form-control input-group-lg" type="text" required name="customername" title="Enter first name" placeholder="Your Name" value="">
                </div>
               
            </div>

            <div class="row">
                <div class="form-group col-xs-12">
                    <label for="email" class="sr-only">Email</label>
                    <input style="text-shadow:0 0 8px #0255fda6; color:white;" id="email" class="form-control input-group-lg" type="email" name="email" required title="Enter Email" placeholder="Your Email" value="">
                    <div id="email-status" style="position: absolute; right: 0; font-weight: 100;  top: 5px;"></div>
                </div>
            </div>
            <div class="row">
                    <div class="form-group col-xs-12">
                        <label for="address" class="sr-only">Address</label>
                        <input style="text-shadow:0 0 8px #0255fda6; color:white;" id="address" class="form-control input-group-lg" type="text" required name="address" title="Enter your address" placeholder="Your address">
                    </div>
                </div>
				
				
				<div class="row">
                    <div class="form-group col-xs-12">
                        <label for="mobile" class="sr-only">Mobile Number</label>
                        <input style="text-shadow:0 0 8px #0255fda6; color:white;" id="mobile" class="form-control input-group-lg" type="text" require name="mobile" title="Enter your mobile number" placeholder="Your mobile number">
                    </div>
                </div>

                
                <div class="row">
                    <div class="form-group col-xs-6">
                        <label for="brandname" class="sr-only">Brand name</label>
                        <input style="text-shadow:0 0 8px #0255fda6; color:white;" id="brand" class="form-control input-group-lg" type="text" require name="brand" title="Enter Brand Name" placeholder="Product Brand Name">
                    </div>
                    <div class="form-group col-xs-6">
                        <label for="model" class="sr-only">Model</label>
                        <input style="text-shadow:0 0 8px #0255fda6; color:white;" id="model" class="form-control input-group-lg" type="text" require name="model" title="Enter product model" placeholder="Product Model">
                    </div>
                </div>

                 
                 <div class="row">
                    <div class="form-group col-xs-6">
                        <label for="price" class="sr-only">Price</label>
                        <input style="text-shadow:0 0 8px #0255fda6; color:white;" id="price" class="form-control input-group-lg" type="number" require name="price" title="Enter desired price" placeholder="price">
                    </div>
                    <div class="form-group col-xs-6">
                        <label for="color" class="sr-only">color</label>
                        <input style="text-shadow:0 0 8px #0255fda6; color:white;" id="color" class="form-control input-group-lg" type="text" require name="color" title="Enter product color" placeholder="color">
                    </div>
                </div>

                <div>
                    <font style="text-shadow: 0 0  #0255fda6;color:white;">Enter Product Type:&nbsp;&nbsp;&nbsp;</font>
                    <input type="radio" name="producttype" value="car" required > <font style="text-shadow: 0 0  #0255fda6;color:white;">&nbsp;Car&nbsp;</font>
                    <input type="radio" name="producttype" value="bike" required><font style="text-shadow: 0 0  #0255fda6; color:white;">&nbsp;Bike&nbsp;</font>
                </div>



                
				
				
            
            <div class="row" style="margin-left: 5px;">
                
            </div>
            <div class="row">
            <input style="color:black;" type="submit" value="Order Now" class="btn btn-primary col-xs-12 btn-submit" name="signup" > 
            </div>
        </form>
    </div>
<div class="col-md-2"></div>
   
</div>


<br><br><br><br><br><br>
<!--js scripts -->
            <script src="https://code.jquery.com/jquery-2.2.4.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
            <script src="https://www.google.com/recaptcha/api.js"></script>
            
    </body>
</html>
